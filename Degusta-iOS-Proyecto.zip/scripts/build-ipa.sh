#!/usr/bin/env bash
set -euo pipefail

bundle_id=${BUNDLE_ID:-com.eduardo.degusta}
signing=${SIGNING:-unsigned}
[[ "$bundle_id" =~ ^[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$ ]]
[[ "$signing" == unsigned || "$signing" == signed ]]
work=$(mktemp -d)
keychain="$work/degusta.keychain-db"
profile_installed=""
previous_keychains=()
keychains_changed=false
cleanup() {
    if [[ -n "$profile_installed" ]]; then rm -f "$profile_installed"; fi
    if [[ "$keychains_changed" == true ]]; then
        security list-keychains -d user -s "${previous_keychains[@]}" || true
    fi
    if [[ -f "$keychain" ]]; then security delete-keychain "$keychain" >/dev/null 2>&1 || true; fi
    rm -r "$work"
}
trap cleanup EXIT

settings=(CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO)
if [[ "$signing" == signed ]]; then
    : "${IOS_CERTIFICATE_BASE64:?Configura IOS_CERTIFICATE_BASE64}"
    : "${IOS_CERTIFICATE_PASSWORD?Configura IOS_CERTIFICATE_PASSWORD}"
    : "${IOS_PROFILE_BASE64:?Configura IOS_PROFILE_BASE64}"
    printf '%s' "$IOS_CERTIFICATE_BASE64" | base64 -D > "$work/cert.p12"
    printf '%s' "$IOS_PROFILE_BASE64" | base64 -D > "$work/profile.mobileprovision"
    security cms -D -i "$work/profile.mobileprovision" > "$work/profile.plist"
    uuid=$(/usr/libexec/PlistBuddy -c 'Print :UUID' "$work/profile.plist")
    team=$(/usr/libexec/PlistBuddy -c 'Print :TeamIdentifier:0' "$work/profile.plist")
    app_id=$(/usr/libexec/PlistBuddy -c 'Print :Entitlements:application-identifier' "$work/profile.plist")
    [[ "$app_id" == "$team.$bundle_id" || "$app_id" == "$team.*" ]] || {
        echo "El identificador del perfil no coincide con $bundle_id" >&2
        exit 1
    }
    /usr/libexec/PlistBuddy -c 'Print :ProvisionedDevices:0' "$work/profile.plist" >/dev/null || {
        echo 'Usa un perfil Development o Ad Hoc con el UDID del iPhone.' >&2
        exit 1
    }
    profile_dir="$HOME/Library/Developer/Xcode/UserData/Provisioning Profiles"
    mkdir -p "$profile_dir"
    profile_installed="$profile_dir/$uuid.mobileprovision"
    [[ ! -e "$profile_installed" ]] || { profile_installed=""; echo "Ese perfil ya está instalado." >&2; exit 1; }
    cp "$work/profile.mobileprovision" "$profile_installed"
    key_password=$(openssl rand -hex 20)
    security create-keychain -p "$key_password" "$keychain"
    security set-keychain-settings -lut 1800 "$keychain"
    security unlock-keychain -p "$key_password" "$keychain"
    security import "$work/cert.p12" -k "$keychain" -P "$IOS_CERTIFICATE_PASSWORD" -T /usr/bin/codesign -T /usr/bin/security
    while IFS= read -r path; do
        previous_keychains+=("$path")
    done < <(security list-keychains -d user | sed -E 's/^[[:space:]]*"//; s/"$//')
    security list-keychains -d user -s "$keychain" "${previous_keychains[@]}"
    keychains_changed=true
    security set-key-partition-list -S apple-tool:,apple:,codesign: -s -k "$key_password" "$keychain" >/dev/null
    identity=$(security find-identity -v -p codesigning "$keychain" | awk '/^[[:space:]]*[0-9]+\)/ {print $2; exit}')
    [[ -n "$identity" ]]
    settings=(CODE_SIGN_STYLE=Manual "DEVELOPMENT_TEAM=$team" "PROVISIONING_PROFILE=$uuid"
              "CODE_SIGN_IDENTITY=$identity" "OTHER_CODE_SIGN_FLAGS=--keychain $keychain")
fi

xcodebuild -project Degusta.xcodeproj -scheme Degusta -configuration Release \
    -destination 'generic/platform=iOS' -derivedDataPath "$work/build" \
    "PRODUCT_BUNDLE_IDENTIFIER=$bundle_id" "CURRENT_PROJECT_VERSION=${GITHUB_RUN_NUMBER:-1}" \
    "${settings[@]}" build

app="$work/build/Build/Products/Release-iphoneos/Degusta.app"
test -f "$app/Degusta"
if [[ "$signing" == signed ]]; then
    test -f "$app/embedded.mobileprovision"
    codesign --verify --deep --strict "$app"
fi
mkdir -p "$work/ipa/Payload" artifacts
ditto "$app" "$work/ipa/Payload/Degusta.app"
ditto -c -k "$work/ipa" "$PWD/artifacts/Degusta-$signing.ipa"
unzip -tq "artifacts/Degusta-$signing.ipa"
