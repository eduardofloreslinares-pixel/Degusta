import SwiftUI

func ratingTint(_ rating: Double) -> Color {
    switch rating {
    case ..<3: .red
    case ..<4: .pink
    case ..<6: .orange
    case ..<7: .yellow
    case ..<8: .mint
    case ..<9: .green
    default: .teal
    }
}

func ratingTitle(_ rating: Double) -> String {
    switch rating {
    case ..<3: "No recomendable"
    case ..<4: "Bajo"
    case ..<6: "Regular"
    case ..<7: "Bueno"
    case ..<8: "Muy bueno"
    case ..<9: "Excelente"
    default: "Obra maestra"
    }
}

struct ScoreBadge: View {
    let rating: Double
    var body: some View {
        Text("\(score(rating))/10")
            .font(.subheadline.weight(.bold).monospacedDigit())
            .padding(.horizontal, 8).padding(.vertical, 5)
            .background(ratingTint(rating).opacity(0.20), in: .rect(cornerRadius: 10))
    }
}

struct ReviewRow: View {
    let group: [Review]
    let rank: Int
    let open: (Review) -> Void
    @State private var expanded = false

    private var latest: Review { group[0] }
    private var rating: Double { average(group.map(\.rating)) }
    private var place: String {
        group.allSatisfy { samePlace($0.place, latest.place) } ? latest.place : "Varios lugares"
    }

    var body: some View {
        VStack(spacing: 0) {
            Button {
                if group.count == 1 { open(latest) }
                else { withAnimation(.snappy) { expanded.toggle() } }
            } label: {
                HStack(alignment: .top, spacing: 12) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("#\(rank) · \(latest.emoji) \(latest.category)").font(.caption).foregroundStyle(.secondary)
                        HStack(spacing: 5) {
                            Text(latest.name).font(.headline)
                            if group.count > 1 {
                                Text("×\(group.count)").font(.caption2.bold())
                                    .padding(4).background(.red.opacity(0.15), in: .capsule)
                                    .foregroundStyle(.red)
                            }
                        }
                        Text([place, priceRange(group)].filter { !$0.isEmpty }.joined(separator: " · "))
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                    VStack(alignment: .trailing, spacing: 5) {
                        Text(latest.date, format: .dateTime.day().month(.abbreviated).year())
                            .font(.caption2).foregroundStyle(.secondary)
                        ScoreBadge(rating: rating)
                        Text(ratingTitle(rating)).font(.caption2).foregroundStyle(.secondary)
                    }
                }
                .padding(14)
                .contentShape(.rect)
            }
            .buttonStyle(.plain)

            if expanded {
                VStack(spacing: 0) {
                    ForEach(group) { entry in
                        Divider()
                        Button { open(entry) } label: {
                            HStack {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(entry.name).font(.subheadline.weight(.semibold))
                                    Text("\(entry.place) · \(entry.date.formatted(date: .abbreviated, time: .omitted))")
                                        .font(.caption).foregroundStyle(.secondary)
                                    if entry.price != nil {
                                        Text(priceRange([entry])).font(.caption2).foregroundStyle(.secondary)
                                    }
                                }
                                Spacer()
                                ScoreBadge(rating: entry.rating)
                            }
                            .padding(.horizontal, 14).padding(.vertical, 9)
                            .contentShape(.rect)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .background(.orange.opacity(0.05))
            }
        }
    }
}

struct ReviewEditor: View {
    @State var review: Review
    let save: (Review) throws -> Void
    @State private var priceText = ""
    @Environment(\.dismiss) private var dismiss
    @State private var error: String?

    private var calculated: Double { average(review.items.map(\.rating)) }

    var body: some View {
        NavigationStack {
            Form {
                Section("Comida") {
                    TextField("Nombre", text: $review.name)
                    TextField("Lugar", text: $review.place)
                    DatePicker("Fecha", selection: $review.date, displayedComponents: .date)
                    Picker("Categoría", selection: $review.category) {
                        Text("Sin categoría").tag("")
                        ForEach(Category.all) { Text("\($0.emoji) \($0.name)").tag($0.name) }
                    }
                    HStack {
                        Picker("Moneda", selection: $review.currency) {
                            ForEach(["S/", "$", "€"], id: \.self) { Text($0).tag($0) }
                        }.labelsHidden()
                        TextField("Precio (opcional)", text: $priceText)
                            .keyboardType(.decimalPad)
                    }
                }
                Section("Calificación") {
                    if !review.items.isEmpty {
                        Toggle("Promediar componentes", isOn: $review.automatic)
                    }
                    if review.automatic && !review.items.isEmpty {
                        LabeledContent("Nota global", value: "\(score(calculated))/10")
                    } else {
                        RatingField(rating: $review.rating)
                    }
                    TextField("Comentario", text: $review.comments, axis: .vertical).lineLimit(2...5)
                }
                Section("Componentes") {
                    ForEach($review.items) { $item in
                        VStack(alignment: .leading, spacing: 8) {
                            TextField("Nombre del componente", text: $item.name)
                            RatingField(rating: $item.rating)
                            TextField("Comentario", text: $item.comment)
                        }
                    }
                    .onDelete { review.items.remove(atOffsets: $0) }
                    Button("Añadir componente", systemImage: "plus") { review.items.append(Item()) }
                }
            }
            .onAppear { priceText = review.price.map { String($0) } ?? "" }
            .navigationTitle(review.name.isEmpty ? "Nueva reseña" : "Reseña")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Guardar", action: commit).bold() }
            }
            .alert("Revisa la reseña", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("Aceptar", role: .cancel) { error = nil }
            } message: { Text(error ?? "") }
        }
    }

    private func commit() {
        var draft = review
        draft.name = draft.name.trimmingCharacters(in: .whitespacesAndNewlines)
        draft.place = draft.place.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !draft.name.isEmpty, !draft.place.isEmpty else { error = "Escribe el nombre y el lugar."; return }
        guard draft.items.allSatisfy({ !$0.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }) else {
            error = "Escribe el nombre de cada componente."; return
        }
        if priceText.trimmingCharacters(in: .whitespaces).isEmpty { draft.price = nil }
        else {
            guard let price = Double(priceText.replacingOccurrences(of: ",", with: ".")),
                  price.isFinite, price >= 0 else { error = "Escribe un precio válido."; return }
            draft.price = price
        }
        if draft.automatic && !draft.items.isEmpty { draft.rating = calculated }
        do { try save(draft); dismiss() }
        catch { self.error = "No se pudo guardar la reseña." }
    }
}

struct RatingField: View {
    @Binding var rating: Double
    @State private var draft = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("Nota")
                Spacer()
                TextField("0–10", text: $draft)
                    .keyboardType(.decimalPad)
                    .multilineTextAlignment(.trailing)
                    .accessibilityLabel("Nota de cero a diez")
                Text("/10").foregroundStyle(.secondary)
            }
            Slider(value: Binding(get: { rating }, set: {
                rating = $0
                draft = score($0)
            }), in: 0...10, step: 0.25).accessibilityLabel("Ajustar nota")
        }
        .onAppear { draft = score(rating) }
        .onChange(of: draft) { _, value in
            if let number = Double(value.replacingOccurrences(of: ",", with: ".")), number.isFinite {
                rating = min(10, max(0, number))
            }
        }
    }
}

struct ReviewDetail: View {
    let review: Review
    let onEdit: () -> Void
    let onDelete: () -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var confirming = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    LabeledContent("Lugar", value: review.place)
                    LabeledContent("Fecha", value: review.date.formatted(date: .abbreviated, time: .omitted))
                    if review.price != nil { LabeledContent("Precio", value: priceRange([review])) }
                    LabeledContent("Nota global") { ScoreBadge(rating: review.rating) }
                    if !review.comments.isEmpty { Text(review.comments) }
                }
                if !review.items.isEmpty {
                    Section("Componentes") {
                        ForEach(review.items) { item in
                            VStack(alignment: .leading) {
                                LabeledContent(item.name) { ScoreBadge(rating: item.rating) }
                                if !item.comment.isEmpty { Text(item.comment).foregroundStyle(.secondary) }
                            }
                        }
                    }
                }
                Section { Button("Eliminar reseña", role: .destructive) { confirming = true } }
            }
            .navigationTitle(review.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cerrar") { dismiss() } }
                ToolbarItem(placement: .primaryAction) {
                    HStack {
                        ShareLink(item: "\(review.name) · \(review.place) · \(score(review.rating))/10\n\(review.comments)")
                        Button("Editar", action: onEdit)
                    }
                }
            }
            .confirmationDialog("¿Eliminar esta reseña?", isPresented: $confirming, titleVisibility: .visible) {
                Button("Eliminar", role: .destructive, action: onDelete)
            }
        }
    }
}
