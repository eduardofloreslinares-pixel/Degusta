import Foundation
import Observation

struct Category: Identifiable, Hashable {
    let name: String
    let emoji: String
    var id: String { name }

    static let all: [Category] = [
        .init(name: "Hamburguesa", emoji: "🍔"), .init(name: "Casera", emoji: "🍲"),
        .init(name: "Peruana", emoji: "🇵🇪"), .init(name: "Pasta", emoji: "🍝"),
        .init(name: "Chifa", emoji: "🥡"), .init(name: "Sushi", emoji: "🍣"),
        .init(name: "Mexicana", emoji: "🌮"), .init(name: "Pizza", emoji: "🍕"),
        .init(name: "Carnes y Parrilla", emoji: "🥩"), .init(name: "Pollos y Broaster", emoji: "🍗"),
        .init(name: "Mariscos y Ceviche", emoji: "🦐"), .init(name: "Sándwiches", emoji: "🥪"),
        .init(name: "Saludable", emoji: "🥗"), .init(name: "Postres y Café", emoji: "🍰")
    ]
}

struct Item: Codable, Identifiable {
    var id = UUID()
    var name = ""
    var rating = 0.0
    var comment = ""
}

struct Review: Codable, Identifiable {
    var id = UUID()
    var name = ""
    var place = ""
    var date = Date()
    var price: Double?
    var currency = "S/"
    var category = ""
    var rating = 0.0
    var comments = ""
    var items: [Item] = []
    var automatic = false

    var emoji: String { Category.all.first { $0.name == category }?.emoji ?? "🍽️" }
}

@Observable
final class ReviewStore {
    private(set) var reviews: [Review] = []
    private(set) var loadError: String?
    private let file: URL

    init() {
        file = URL.applicationSupportDirectory.appending(path: "Degusta-reviews.json")
        guard FileManager.default.fileExists(atPath: file.path) else { return }
        do { reviews = try JSONDecoder().decode([Review].self, from: Data(contentsOf: file)) }
        catch { loadError = "No se pudieron leer las reseñas guardadas." }
    }

    func save(_ review: Review) throws {
        var updated = reviews
        if let index = updated.firstIndex(where: { $0.id == review.id }) { updated[index] = review }
        else { updated.append(review) }
        try persist(updated)
    }

    func delete(_ id: UUID) throws {
        try persist(reviews.filter { $0.id != id })
    }

    private func persist(_ updated: [Review]) throws {
        guard loadError == nil else { throw CocoaError(.fileWriteUnknown) }
        try FileManager.default.createDirectory(at: file.deletingLastPathComponent(), withIntermediateDirectories: true)
        try JSONEncoder().encode(updated).write(to: file, options: .atomic)
        reviews = updated
    }
}

func words(_ value: String) -> [String] {
    value.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "es"))
        .split { !$0.isLetter && !$0.isNumber }.map(String.init)
}

func oneEdit(_ lhs: String, _ rhs: String) -> Bool {
    let a = Array(lhs), b = Array(rhs)
    guard abs(a.count - b.count) <= 1 else { return false }
    if a.count > b.count { return oneEdit(rhs, lhs) }
    guard let index = a.indices.first(where: { a[$0] != b[$0] }) else { return true }
    if a.count < b.count { return a[index...] == b[(index + 1)...] }
    if a[(index + 1)...] == b[(index + 1)...] { return true }
    return index + 1 < a.count && a[index] == b[index + 1] && a[index + 1] == b[index]
        && a[(index + 2)...] == b[(index + 2)...]
}

func similar(_ lhs: String, _ rhs: String) -> Bool {
    let left = words(lhs), right = words(rhs)
    guard !left.isEmpty, !right.isEmpty, abs(left.count - right.count) <= 1 else { return false }
    let short = left.count <= right.count ? left : right
    var remaining = left.count <= right.count ? right : left
    let missing = short.filter { word in
        guard let index = remaining.firstIndex(of: word) else { return true }
        remaining.remove(at: index)
        return false
    }
    if missing.isEmpty { return true }
    return missing.count == 1 && remaining.contains { word in
        min(word.count, missing[0].count) >= 4
        && !(word + missing[0]).contains(where: \.isNumber)
        && oneEdit(word, missing[0])
    }
}

func samePlace(_ lhs: String, _ rhs: String) -> Bool {
    let a = words(lhs).joined(), b = words(rhs).joined()
    return a == b || similar(lhs, rhs)
        || (min(a.count, b.count) >= 5 && !(a + b).contains(where: \.isNumber) && oneEdit(a, b))
}

func mainTitle(_ value: String) -> String {
    value.replacingOccurrences(of: #"(?i)^\s*combo\s+"#, with: "", options: .regularExpression)
}

func clusters<T>(_ values: [T], matches: (T, T) -> Bool) -> [[T]] {
    var groups: [[T]] = []
    for value in values {
        if let index = groups.firstIndex(where: { $0.allSatisfy { matches($0, value) } }) {
            groups[index].append(value)
        } else { groups.append([value]) }
    }
    return groups
}

func average(_ values: [Double]) -> Double {
    values.isEmpty ? 0 : values.reduce(0, +) / Double(values.count)
}

func score(_ value: Double) -> String { value.formatted(.number.precision(.fractionLength(1...2))) }
func amount(_ value: Double) -> String { value.formatted(.number.precision(.fractionLength(2))) }
func priceRange(_ entries: [Review]) -> String {
    let priced = entries.compactMap { entry in entry.price.map { (entry.currency, $0) } }
    return Dictionary(grouping: priced, by: { $0.0 }).sorted(by: { $0.key < $1.key })
        .compactMap { currency, values in
            let prices = values.map { $0.1 }
            guard let low = prices.min(), let high = prices.max() else { return nil }
            return "\(currency) \(amount(low))" + (low == high ? "" : "–\(amount(high))")
        }.joined(separator: " · ")
}

struct RankedReviews: Identifiable {
    let id: UUID
    let rank: Int
    let reviews: [Review]
}

func rankedGroups(_ groups: [[Review]]) -> [RankedReviews] {
    groups.enumerated().compactMap { index, reviews in
        guard let first = reviews.first else { return nil }
        return RankedReviews(id: first.id, rank: index + 1, reviews: reviews)
    }
}
