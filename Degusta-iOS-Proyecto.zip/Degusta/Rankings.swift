import SwiftUI

private struct RankingEntry: Identifiable {
    let name: String
    var place = ""
    let count: Int
    let rating: Double
    var id: String { name + "\u{1f}" + place }
}

private func placeGroups(_ reviews: [Review]) -> [[Review]] {
    clusters(reviews) { samePlace($0.place, $1.place) }
}

private func locations(_ reviews: [Review]) -> [RankingEntry] {
    placeGroups(reviews).map {
        RankingEntry(name: $0[0].place, count: $0.count, rating: average($0.map(\.rating)))
    }
}

private func complements(_ reviews: [Review]) -> [RankingEntry] {
    placeGroups(reviews).flatMap { place in
        let sides = place.flatMap { review in
            let title = mainTitle(review.name)
            let main = title.components(separatedBy: " + ").first ?? title
            return review.items.filter { !similar($0.name, main) }
        }
        return clusters(sides) { similar($0.name, $1.name) }.map {
            RankingEntry(name: $0[0].name, place: place[0].place, count: $0.count, rating: average($0.map(\.rating)))
        }
    }
}

private enum Ranking: String, CaseIterable, Identifiable {
    case meals = "Platos"
    case frequency = "Más frecuentados"
    case sides = "Complementos"
    case places = "Lugares por nota"
    var id: Self { self }
}

struct PodiumView: View {
    let reviews: [Review]
    let groups: [[Review]]
    let open: (Review) -> Void
    @State private var mode = Ranking.meals

    private var rows: [RankingEntry] {
        let values = mode == .sides ? complements(reviews) : locations(reviews)
        return values.sorted { left, right in
            if mode == .frequency && left.count != right.count { return left.count > right.count }
            if left.rating != right.rating { return left.rating > right.rating }
            if left.count != right.count { return left.count > right.count }
            return left.name.localizedStandardCompare(right.name) == .orderedAscending
        }
    }

    var body: some View {
        VStack(spacing: 14) {
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                ForEach(Ranking.allCases) { option in
                    Button { mode = option } label: {
                        Text(option.rawValue).font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity, minHeight: 40)
                    }
                    .buttonStyle(.plain)
                    .glassEffect(mode == option ? .regular.tint(.orange.opacity(0.22)).interactive() : .regular.interactive())
                    .accessibilityAddTraits(mode == option ? .isSelected : [])
                }
            }
            if reviews.isEmpty || (mode != .meals && rows.isEmpty) {
                ContentUnavailableView(mode == .sides ? "Sin complementos" : "Sin reseñas", systemImage: "trophy")
            } else if mode == .meals {
                LazyVStack(spacing: 0) {
                    ForEach(rankedGroups(groups)) { entry in
                        ReviewRow(group: entry.reviews, rank: entry.rank, open: open)
                        if entry.rank < groups.count { Divider().padding(.leading, 14) }
                    }
                }
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: .rect(cornerRadius: 24))
                .clipShape(.rect(cornerRadius: 24))
            } else {
                LazyVStack(spacing: 0) {
                    ForEach(Array(rows.enumerated()), id: \.element.id) { index, row in
                        HStack(spacing: 12) {
                            Text(index < 3 ? ["🥇", "🥈", "🥉"][index] : "\(index + 1)")
                                .frame(width: 28)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(row.name).font(.headline)
                                if !row.place.isEmpty { Text(row.place).font(.subheadline).foregroundStyle(.secondary) }
                                if mode != .frequency { Text("\(row.count) consumos").font(.caption).foregroundStyle(.secondary) }
                            }
                            Spacer()
                            if mode == .frequency { Text("\(row.count) consumos").font(.subheadline.bold()) }
                            else { ScoreBadge(rating: row.rating) }
                        }.padding(14)
                        if index < rows.count - 1 { Divider().padding(.leading, 14) }
                    }
                }
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: .rect(cornerRadius: 24))
            }
        }
    }
}

struct StatisticsView: View {
    let reviews: [Review]
    private var ratings: [Double] { reviews.map(\.rating) }

    var body: some View {
        if reviews.isEmpty {
            ContentUnavailableView("Sin estadísticas", systemImage: "chart.bar.xaxis",
                                   description: Text("Tus reseñas aparecerán aquí cuando registres una comida."))
        } else {
            VStack(alignment: .leading, spacing: 14) {
                Text("Estadísticas").font(.largeTitle.bold())
                VStack(spacing: 12) {
                    LabeledContent("Consumos", value: reviews.count.formatted())
                    LabeledContent("Lugares", value: locations(reviews).count.formatted())
                    LabeledContent("Nota promedio", value: "\(score(average(ratings)))/10")
                    let expenses = Dictionary(grouping: reviews.filter { $0.price != nil }, by: \.currency)
                    ForEach(expenses.keys.sorted(), id: \.self) { currency in
                        let total = expenses[currency, default: []].compactMap(\.price).reduce(0, +)
                        LabeledContent("Total registrado", value: "\(currency) \(amount(total))")
                    }
                }
                .padding()
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: .rect(cornerRadius: 22))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}
