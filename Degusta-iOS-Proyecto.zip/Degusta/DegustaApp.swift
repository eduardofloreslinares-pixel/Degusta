import SwiftUI

@main
struct DegustaApp: App {
    var body: some Scene { WindowGroup { DegustaView() } }
}

private enum Page: Int, CaseIterable, Identifiable {
    case reviews, podium, stats
    var id: Self { self }
    var title: String {
        switch self {
        case .reviews: "Reseñas"
        case .podium: "Top Podio"
        case .stats: "Estadísticas"
        }
    }
    var icon: String {
        switch self {
        case .reviews: "bookmark"
        case .podium: "trophy"
        case .stats: "chart.bar.xaxis"
        }
    }
}

struct DegustaView: View {
    @State private var store = ReviewStore()
    @State private var page = Page.reviews
    @State private var category: String?
    @State private var editing: Review?
    @State private var selection: Review?
    @State private var pendingEdit: Review?
    @State private var error: String?
    @State private var direction = 1
    @Namespace private var dock
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private var ordered: [Review] {
        store.reviews.sorted { $0.date > $1.date }
    }
    private var groups: [[Review]] {
        clusters(ordered) { similar(mainTitle($0.name), mainTitle($1.name)) }
            .sorted { average($0.map(\.rating)) > average($1.map(\.rating)) }
    }

    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: 14) {
                    if let issue = store.loadError { Text(issue).foregroundStyle(.red) }
                    switch page {
                    case .reviews:
                        let shown = groups.filter { group in
                            category == nil || group.contains { $0.category == category }
                        }
                        if shown.isEmpty {
                            ContentUnavailableView(
                                store.reviews.isEmpty ? "Sin reseñas" : "Sin resultados",
                                systemImage: "fork.knife",
                                description: Text(store.reviews.isEmpty ? "Toca + para calificar una comida." : "Prueba con otra categoría.")
                            )
                        } else {
                            mealList(shown)
                        }
                    case .podium:
                        PodiumView(reviews: ordered, groups: groups) { selection = $0 }
                    case .stats:
                        StatisticsView(reviews: ordered)
                    }
                }
                .id(page)
                .transition(.asymmetric(
                    insertion: .offset(x: CGFloat(direction) * 22).combined(with: .opacity),
                    removal: .opacity
                ))
                .padding(.horizontal, 16)
                .padding(.top, geometry.safeAreaInsets.top + 64)
                .padding(.bottom, geometry.safeAreaInsets.bottom + 82)
                .frame(maxWidth: 660)
                .frame(maxWidth: .infinity)
            }
            .scrollIndicators(.hidden)
            .simultaneousGesture(DragGesture(minimumDistance: 26).onEnded { gesture in
                let x = gesture.translation.width
                let y = gesture.translation.height
                guard abs(x) > 56, abs(x) > abs(y) * 1.6,
                      let next = Page(rawValue: page.rawValue + (x < 0 ? 1 : -1)) else { return }
                change(to: next)
            })
            .ignoresSafeArea(edges: .vertical)
        }
        .background {
            LinearGradient(colors: [Color.orange.opacity(0.13), Color(uiColor: .systemGroupedBackground),
                                    Color.purple.opacity(0.09)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
        }
        .overlay(alignment: .top) { filters.padding(.top, 3) }
        .overlay(alignment: .bottom) { navigation.padding(.bottom, 3) }
        .sheet(item: $editing) { draft in
            ReviewEditor(review: draft) { try store.save($0) }
        }
        .sheet(item: $selection, onDismiss: {
            if let pendingEdit {
                editing = pendingEdit
                self.pendingEdit = nil
            }
        }) { review in
            ReviewDetail(review: review, onEdit: {
                pendingEdit = review
                selection = nil
            }, onDelete: {
                do { try store.delete(review.id); selection = nil }
                catch { self.error = "No se pudo eliminar la reseña." }
            })
        }
        .alert("Degusta", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
            Button("Aceptar", role: .cancel) { error = nil }
        } message: { Text(error ?? "") }
    }

    private func mealList(_ items: [[Review]]) -> some View {
        LazyVStack(spacing: 0) {
            ForEach(rankedGroups(items)) { entry in
                ReviewRow(group: entry.reviews, rank: entry.rank) { selection = $0 }
                if entry.rank < items.count { Divider().padding(.leading, 14) }
            }
        }
        .background(Color(uiColor: .secondarySystemGroupedBackground).opacity(0.84), in: .rect(cornerRadius: 24))
    }

    private var filters: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 5) {
                categoryButton("🍽️", name: nil)
                ForEach(Category.all) { item in categoryButton(item.emoji, name: item.name) }
            }
            .padding(4)
        }
        .scrollIndicators(.hidden)
        .frame(maxWidth: 570)
        .glassEffect(.regular, in: .capsule)
        .padding(.horizontal, 16)
        .background(alignment: .top) {
            Rectangle().fill(.ultraThinMaterial)
                .mask { LinearGradient(colors: [.black, .black, .clear], startPoint: .top, endPoint: .bottom) }
                .padding(.bottom, -19)
                .ignoresSafeArea(edges: .top)
                .allowsHitTesting(false)
        }
    }

    private func categoryButton(_ emoji: String, name: String?) -> some View {
        Button {
            category = category == name ? nil : name
            change(to: .reviews)
        } label: {
            Text(emoji).font(.title3)
                .frame(width: 43, height: 43)
                .background(category == name ? Color.orange.opacity(0.22) : .clear, in: .circle)
                .contentShape(.circle)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(name ?? "Todas las comidas")
        .accessibilityAddTraits(category == name ? .isSelected : [])
    }

    private var navigation: some View {
        GlassEffectContainer(spacing: 10) {
            HStack(spacing: 10) {
                HStack(spacing: 0) {
                    ForEach(Page.allCases) { item in
                        Button {
                            change(to: item)
                        } label: {
                            VStack(spacing: 4) {
                                Image(systemName: item.icon).font(.system(size: 19, weight: .semibold))
                                Text(item.title).font(.system(size: 10, weight: .semibold)).lineLimit(1)
                            }
                            .foregroundStyle(item == page ? Color.orange : Color.primary)
                            .frame(maxWidth: .infinity)
                            .frame(height: 49)
                            .background {
                                if item == page {
                                    Capsule().fill(Color.orange.opacity(0.14))
                                        .matchedGeometryEffect(id: "selection", in: dock)
                                }
                            }
                            .contentShape(.capsule)
                        }
                        .buttonStyle(.plain)
                        .accessibilityAddTraits(item == page ? .isSelected : [])
                    }
                }
                .padding(4)
                .glassEffect(.regular.interactive(), in: .capsule)
                Button {
                    editing = Review(category: category ?? "")
                } label: {
                    Image(systemName: "plus").font(.system(size: 25, weight: .medium))
                        .frame(width: 57, height: 57)
                        .contentShape(.circle)
                }
                .buttonStyle(.plain)
                .glassEffect(.regular.interactive(), in: .circle)
                .accessibilityLabel("Calificar comida")
            }
        }
        .frame(maxWidth: 490)
        .padding(.horizontal, 15)
    }

    private func change(to next: Page) {
        guard next != page else { return }
        direction = next.rawValue > page.rawValue ? 1 : -1
        withAnimation(reduceMotion ? nil : .spring(response: 0.32, dampingFraction: 0.82)) { page = next }
    }
}
