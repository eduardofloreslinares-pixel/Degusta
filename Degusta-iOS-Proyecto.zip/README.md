# Degusta para iPhone

App nativa en SwiftUI para iOS 26 o posterior. Usa Liquid Glass de SwiftUI en los filtros y los controles flotantes. Guarda las reseñas localmente en este iPhone. Las reseñas de la app Android se mantienen en el dispositivo donde fueron registradas.

## Generar el IPA en GitHub Actions

1. Descomprime este ZIP. Sube el **contenido** de la carpeta a la raíz de tu repositorio. Incluye la carpeta oculta `.github`, que contiene `.github/workflows/ipa.yml`.
2. En GitHub, abre **Actions → Degusta IPA → Run workflow**. Selecciona `unsigned` para generar un IPA que puedes firmar después con tu método de instalación. Un push a `main` también genera un IPA sin firmar.
3. Al terminar, abre la ejecución y descarga **Degusta-IPA-unsigned** en **Artifacts**. El archivo descargado contiene `Degusta-unsigned.ipa`.

El proyecto usa el runner `macos-26` y comprueba que el SDK de iOS sea 26 o posterior. No necesita dependencias externas.

## Generar un IPA firmado para un iPhone registrado

Crea un perfil **Development** o **Ad Hoc** que incluya el UDID de tu iPhone. Exporta el certificado que autorizaste en ese perfil junto con su clave privada, en un archivo `.p12`.

En **Settings → Secrets and variables → Actions**, crea estos secretos:

| Secreto | Valor |
| --- | --- |
| `IOS_CERTIFICATE_BASE64` | Contenido del `.p12` en Base64 |
| `IOS_CERTIFICATE_PASSWORD` | Contraseña del `.p12` |
| `IOS_PROFILE_BASE64` | Contenido del `.mobileprovision` en Base64 |

En macOS puedes obtener cada valor con `base64 -i archivo.p12` y `base64 -i perfil.mobileprovision`. Usa los secretos del repositorio para estos valores.

Ejecuta el workflow manualmente con `signed` y el **bundle ID** de tu perfil. Descarga **Degusta-IPA-signed**. El IPA se puede instalar en los dispositivos del perfil mediante el procedimiento de Apple para dispositivos registrados.

- [Distribuir en dispositivos registrados](https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices/)
- [Crear un perfil Ad Hoc](https://developer.apple.com/la/help/account/provisioning-profiles/create-an-ad-hoc-provisioning-profile/)

## Abrir en Xcode

Abre `Degusta.xcodeproj` con Xcode 26 o posterior y elige el esquema **Degusta**. Para probar en el simulador, selecciona un iPhone con iOS 26 o posterior. Para ejecutar en tu iPhone desde Xcode, configura tu equipo en **Signing & Capabilities**.
